import {Pageone} from './pages/Pageone';
import './App.css';

function App() {
  return (
    <div>
      <Pageone />
    </div>
  );
}


export default App;
