import React from 'react';

export {Pageone} from './Pageone';
export {Pagetwo} from './Pagetwo';
export {Pagethree} from './Pagethree';
export {Pagefour} from './Pagefour';