import './App.css';
import { UsersList } from './UsersList';

function App() {
  return (
    <div >
      <UsersList />
    </div>
  );
}

export default App;
