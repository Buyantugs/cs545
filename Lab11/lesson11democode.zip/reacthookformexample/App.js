import { Entryform } from './pages/EntryForm';
import './App.css';

function App() {
  return (
    <div>
      <Entryform />
    </div>
  );
}

export default App;
