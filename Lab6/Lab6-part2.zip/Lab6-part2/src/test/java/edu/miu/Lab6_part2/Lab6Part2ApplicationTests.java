package edu.miu.Lab6_part2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab6Part2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
