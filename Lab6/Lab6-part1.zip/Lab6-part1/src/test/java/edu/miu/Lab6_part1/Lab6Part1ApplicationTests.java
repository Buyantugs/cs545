package edu.miu.Lab6_part1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab6Part1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
