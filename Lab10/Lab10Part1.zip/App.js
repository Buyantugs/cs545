import logo from './logo.svg';
import './App.css';
import { FormPage } from './FormPage';

function App() {
  return (
    <FormPage/>
  );
}

export default App;
