package jwtexample.models;

public enum Role {
  ROLE_ADMIN,
  ROLE_USER
}
