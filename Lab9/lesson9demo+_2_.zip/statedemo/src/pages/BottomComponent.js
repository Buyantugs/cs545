import React from 'react';

export const BottomComponent = ({ message }) => {

    let content = 
       <div>
         <p>
          {message}
        </p>
       </div>
    return content ;
}

