import React from 'react';

export const BottomComponent = () =>{
    let message = "This is a message";

    let content = 
       <div>
         <p>
          {message}
        </p>
       </div>
    return content ;
}

