import React from 'react';

export const Component3 = () => {

  let component = (
      <table>
        <tr>
          <th><h3>Component 3</h3></th>
        </tr>
        <tr>
          <th><button>Click me!</button></th>
        </tr>
      </table>
  );
  return component;
}