import React from 'react';

export const Component4 = () => {

  let component = (
      <table>
        <tr>
          <th><h3>Component 4</h3></th>
        </tr>
        <tr>
          <th><button>Click me!</button></th>
        </tr>
      </table>
  );
  return component;
}