import React from 'react';

export const Component2 = () => {

  let component = (
      <table>
        <tr>
          <th><h3>Component 2</h3></th>
        </tr>
        <tr>
          <th><button>Click me!</button></th>
        </tr>
      </table>
  );
  return component;
}