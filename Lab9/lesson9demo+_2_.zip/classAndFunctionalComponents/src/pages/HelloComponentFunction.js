import React from 'react';

export const HelloComponentFunction = () => {
    return  (
        <h1>Hello World</h1>
    );
}