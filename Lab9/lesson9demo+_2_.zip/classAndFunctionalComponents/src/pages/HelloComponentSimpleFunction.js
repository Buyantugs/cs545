import React from 'react';

export function HelloComponentSimpleFunction () {
    return (
        <h1>Hello World</h1>
    );
}
