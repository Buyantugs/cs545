package edu.miu.Lab5_part3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot_Bank_MVC {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot_Bank_MVC.class, args);
	}

}
